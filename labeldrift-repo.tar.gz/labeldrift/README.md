# labeldrift

Find hardcoded label/enum strings that have drifted from their canonical constant definitions.

Codebases accumulate bare string literals — `"CRITICAL"`, `"HOLD"`, `"pending"` — that were
supposed to come from a single constants module. Rename the constant and the literals silently
keep working, pointing at nothing. `labeldrift` is an AST-based checker that flags them.

It is not a general-purpose linter. It answers one question: *which files use the raw string
where they should use the constant?*

## Install

```bash
pip install labeldrift
```

## Usage

```bash
labeldrift check src/
labeldrift check src/ --config path/to/labeldrift.toml
```

Exit codes: `0` clean, `1` violations found, `2` config or usage error — so it drops into CI
or a pre-commit hook as-is.

Example output:

```
✗ Found 2 label drift violation(s) in 1 file(s):

  src/pipeline/triage.py:44: use myproject.labels.VERDICT_HOLD instead of bare string 'HOLD'
  src/pipeline/triage.py:91: use myproject.labels.PRIORITY_CRITICAL instead of bare string 'CRITICAL'
```

## Configuration

Config is read from `--config`, then `./labeldrift.toml`, then a `[tool.labeldrift]` table in
`./pyproject.toml`.

```toml
[source]
module = "myproject.labels"       # informational; used in the message text

[[label]]
value = "CRITICAL"                # the literal string to flag
constant = "PRIORITY_CRITICAL"    # the canonical name it should come from

[[label]]
value = "HOLD"
constant = "VERDICT_HOLD"
context = ["pipeline", "triage"]  # optional: only flag inside paths containing
                                  # any of these substrings

[exclude]
paths = ["myproject/labels.py", "test_", ".venv", "__pycache__"]
```

`context` narrows a rule to the paths where the string is meaningful, so a generic word like
`"HOLD"` doesn't fire across the whole tree. `exclude.paths` is substring matching — the
constants module itself belongs here, since its definitions are the legitimate source.

## Python API

```python
from labeldrift import load_config, scan

cfg = load_config("labeldrift.toml")
findings = scan("src", cfg)          # {Path: [Violation, ...]}

for path, violations in findings.items():
    for v in violations:
        print(v.message())
```

## Pre-commit

```yaml
- repo: local
  hooks:
    - id: labeldrift
      name: labeldrift
      entry: labeldrift check src/
      language: system
      pass_filenames: false
```

## Scope and limits

- Python only; files that fail to parse are skipped, not fatal.
- Matches `ast.Constant` string nodes. Labels built inside f-strings or by concatenation are
  not detected.
- Matching is exact and case-sensitive.

## License

MIT
