from __future__ import annotations

from pathlib import Path

import pytest

from labeldrift.config import (
    DEFAULT_EXCLUDES,
    ConfigError,
    LabelRule,
    discover_config,
    load_config,
)

FULL_TOML = """
[source]
module = "myproject.labels"

[[label]]
value = "CRITICAL"
constant = "PRIORITY_CRITICAL"

[[label]]
value = "HOLD"
constant = "VERDICT_HOLD"
context = ["pipeline"]

[exclude]
paths = ["myproject/labels.py", "test_"]
"""


def test_load_config_parses_full_schema(tmp_path: Path) -> None:
    cfg_path = tmp_path / "labeldrift.toml"
    cfg_path.write_text(FULL_TOML, encoding="utf-8")

    cfg = load_config(cfg_path)

    assert cfg.source_module == "myproject.labels"
    assert len(cfg.rules) == 2
    assert cfg.values == {"CRITICAL", "HOLD"}
    assert cfg.exclude_paths == ("myproject/labels.py", "test_")


def test_load_config_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(ConfigError, match="config file not found"):
        load_config(tmp_path / "nope.toml")


def test_label_entry_without_constant_raises(tmp_path: Path) -> None:
    cfg_path = tmp_path / "labeldrift.toml"
    cfg_path.write_text('[[label]]\nvalue = "CRITICAL"\n', encoding="utf-8")

    with pytest.raises(ConfigError, match="needs 'value' and 'constant'"):
        load_config(cfg_path)


def test_defaults_applied_when_sections_omitted(tmp_path: Path) -> None:
    cfg_path = tmp_path / "labeldrift.toml"
    cfg_path.write_text(
        '[[label]]\nvalue = "X"\nconstant = "LABEL_X"\n', encoding="utf-8"
    )

    cfg = load_config(cfg_path)

    assert cfg.source_module == ""
    assert cfg.exclude_paths == DEFAULT_EXCLUDES
    assert cfg.rules[0].context == ()


def test_rule_for_returns_match_and_none(tmp_path: Path) -> None:
    cfg_path = tmp_path / "labeldrift.toml"
    cfg_path.write_text(FULL_TOML, encoding="utf-8")

    cfg = load_config(cfg_path)

    assert cfg.rule_for("HOLD").constant == "VERDICT_HOLD"
    assert cfg.rule_for("NOT_A_LABEL") is None


def test_discover_prefers_standalone_file(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "labeldrift.toml").write_text(FULL_TOML, encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        '[tool.labeldrift.source]\nmodule = "ignored.labels"\n', encoding="utf-8"
    )
    monkeypatch.chdir(tmp_path)

    assert discover_config(".").source_module == "myproject.labels"


def test_discover_falls_back_to_pyproject_table(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "pyproject.toml").write_text(
        '[tool.labeldrift.source]\nmodule = "pkg.labels"\n\n'
        '[[tool.labeldrift.label]]\nvalue = "OPEN"\nconstant = "STATUS_OPEN"\n',
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    cfg = discover_config(".")

    assert cfg.source_module == "pkg.labels"
    assert cfg.values == {"OPEN"}


def test_discover_ignores_pyproject_without_tool_table(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "other"\n', encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    with pytest.raises(ConfigError, match="no config found"):
        discover_config(".")


def test_discover_with_nothing_present_raises(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    with pytest.raises(ConfigError, match="no config found"):
        discover_config(".")


def test_applies_to_without_context_matches_everything() -> None:
    rule = LabelRule(value="X", constant="LABEL_X")

    assert rule.applies_to(Path("anything/at/all.py")) is True


def test_applies_to_with_context_is_substring_scoped() -> None:
    rule = LabelRule(value="HOLD", constant="VERDICT_HOLD", context=("pipeline",))

    assert rule.applies_to(Path("src/pipeline/triage.py")) is True
    assert rule.applies_to(Path("src/web/views.py")) is False
