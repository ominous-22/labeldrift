from __future__ import annotations

from pathlib import Path

import pytest

from labeldrift.cli import main

CONFIG = """
[source]
module = "myproject.labels"

[[label]]
value = "CRITICAL"
constant = "PRIORITY_CRITICAL"
"""


def _project(tmp_path: Path, *, config: str | None = CONFIG, body: str = "a = 1\n") -> Path:
    src = tmp_path / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "app.py").write_text(body, encoding="utf-8")
    if config is not None:
        (tmp_path / "labeldrift.toml").write_text(config, encoding="utf-8")
    return tmp_path


def test_clean_tree_exits_zero(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(_project(tmp_path))

    assert main(["check", "src"]) == 0
    assert "No label drift found" in capsys.readouterr().out


def test_violations_exit_one_and_are_printed(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(_project(tmp_path, body='x = "CRITICAL"\n'))

    assert main(["check", "src"]) == 1
    out = capsys.readouterr().out
    assert "1 label drift violation(s)" in out
    assert "myproject.labels.PRIORITY_CRITICAL" in out


def test_missing_config_exits_two(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(_project(tmp_path, config=None))

    assert main(["check", "src"]) == 2
    assert "no config found" in capsys.readouterr().err


def test_missing_source_dir_exits_two(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(_project(tmp_path))

    assert main(["check", "does_not_exist"]) == 2
    assert "source directory not found" in capsys.readouterr().err


def test_config_without_rules_exits_two(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(_project(tmp_path, config='[source]\nmodule = "m"\n'))

    assert main(["check", "src"]) == 2
    assert "no [[label]] rules" in capsys.readouterr().err


def test_explicit_config_flag_is_used(tmp_path: Path, monkeypatch) -> None:
    project = _project(tmp_path, config=None, body='x = "CRITICAL"\n')
    external = tmp_path / "elsewhere" / "rules.toml"
    external.parent.mkdir(parents=True, exist_ok=True)
    external.write_text(CONFIG, encoding="utf-8")
    monkeypatch.chdir(project)

    assert main(["check", "src", "--config", str(external)]) == 1


def test_src_dir_defaults_to_src(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(_project(tmp_path, body='x = "CRITICAL"\n'))

    assert main(["check"]) == 1


def test_version_flag_exits_zero(capsys) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["--version"])

    assert exc.value.code == 0
    assert "labeldrift" in capsys.readouterr().out


def test_no_subcommand_is_a_usage_error() -> None:
    with pytest.raises(SystemExit) as exc:
        main([])

    assert exc.value.code == 2
