from __future__ import annotations

from pathlib import Path

from labeldrift.config import LabelDriftConfig, LabelRule
from labeldrift.scanner import Violation, scan, scan_file

CFG = LabelDriftConfig(
    source_module="myproject.labels",
    rules=(
        LabelRule(value="CRITICAL", constant="PRIORITY_CRITICAL"),
        LabelRule(value="HOLD", constant="VERDICT_HOLD", context=("pipeline",)),
    ),
    exclude_paths=("labels.py", "__pycache__"),
)


def _write(path: Path, body: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")
    return path


def test_flags_bare_literal_with_correct_lineno(tmp_path: Path) -> None:
    target = _write(tmp_path / "app.py", 'x = 1\ny = "CRITICAL"\n')

    violations = scan_file(target, CFG)

    assert len(violations) == 1
    assert violations[0].lineno == 2
    assert violations[0].constant == "PRIORITY_CRITICAL"


def test_ignores_unconfigured_strings(tmp_path: Path) -> None:
    target = _write(tmp_path / "app.py", 'y = "SOMETHING_ELSE"\n')

    assert scan_file(target, CFG) == []


def test_context_rule_fires_only_inside_matching_path(tmp_path: Path) -> None:
    inside = _write(tmp_path / "pipeline" / "triage.py", 'v = "HOLD"\n')
    outside = _write(tmp_path / "web" / "views.py", 'v = "HOLD"\n')

    assert len(scan_file(inside, CFG)) == 1
    assert scan_file(outside, CFG) == []


def test_multiple_violations_in_one_file(tmp_path: Path) -> None:
    target = _write(tmp_path / "pipeline" / "run.py", 'a = "CRITICAL"\nb = "HOLD"\n')

    assert len(scan_file(target, CFG)) == 2


def test_syntax_error_is_skipped_not_fatal(tmp_path: Path) -> None:
    target = _write(tmp_path / "broken.py", 'def f(:\n    "CRITICAL"\n')

    assert scan_file(target, CFG) == []


def test_missing_file_is_skipped_not_fatal(tmp_path: Path) -> None:
    assert scan_file(tmp_path / "does_not_exist.py", CFG) == []


def test_literals_found_in_nested_nodes(tmp_path: Path) -> None:
    target = _write(
        tmp_path / "app.py",
        "def f():\n    if True:\n        return {'k': ['CRITICAL']}\n",
    )

    assert len(scan_file(target, CFG)) == 1


def test_scan_walks_tree_and_omits_clean_files(tmp_path: Path) -> None:
    _write(tmp_path / "dirty.py", 'a = "CRITICAL"\n')
    _write(tmp_path / "clean.py", "a = 1\n")

    findings = scan(tmp_path, CFG)

    assert list(findings) == [tmp_path / "dirty.py"]


def test_scan_honors_exclude_paths(tmp_path: Path) -> None:
    _write(tmp_path / "labels.py", 'PRIORITY_CRITICAL = "CRITICAL"\n')
    _write(tmp_path / "__pycache__" / "cached.py", 'a = "CRITICAL"\n')

    assert scan(tmp_path, CFG) == {}


def test_scan_ignores_non_python_files(tmp_path: Path) -> None:
    _write(tmp_path / "notes.txt", "CRITICAL\n")

    assert scan(tmp_path, CFG) == {}


def test_message_includes_source_module_when_set() -> None:
    v = Violation(
        path=Path("src/app.py"),
        lineno=7,
        value="CRITICAL",
        constant="PRIORITY_CRITICAL",
        source_module="myproject.labels",
    )

    assert v.message() == (
        "src/app.py:7: use myproject.labels.PRIORITY_CRITICAL "
        "instead of bare string 'CRITICAL'"
    )


def test_message_falls_back_to_bare_constant() -> None:
    v = Violation(
        path=Path("src/app.py"),
        lineno=7,
        value="CRITICAL",
        constant="PRIORITY_CRITICAL",
        source_module="",
    )

    assert "use PRIORITY_CRITICAL instead" in v.message()
